function abc (a,b){
  return c = a+b;
}
document.write("Addition is:-"+abc(85,30));