let no = prompt("Enter Any Number:-");

