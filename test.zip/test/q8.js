let str="Learning JavaScript Program";
str1 = str.replace(/a/g,"A");
document.write("Replace string is:-"+str1);