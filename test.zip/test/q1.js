let str="Hope this article helped you understand JavaScript Examples. In this article, we explored the concept of Javascript code structure with the different ways of declaration";
document.write("the string length is:-"+str.length+"<br>");
let str1="you are looking to upgrade your skill set, you can sign up on our SkillUp platform, a Simplilearn initiative";
document.write("The string length is:-"+str1.length+"<br>");
total = str.length+str1.length;
document.write("Total String is:-"+total);