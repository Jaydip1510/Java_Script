let str="Hello";
let str1="hello";

string=str;
document.write("both string are equal");