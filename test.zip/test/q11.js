let str ="JavaScript is a very absurd programming language";
let ch = str.slice(4,16);
document.write("slice function is:-"+ch+"<br>");