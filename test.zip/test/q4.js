let ch = prompt("Enter Any Character");
upr="A","E","I","O","U";
lwr="a","e","i","o","u";

if(upr = lwr){
    document.write("character is Vowel");
}else{
    document.write("Invalid Input");
}