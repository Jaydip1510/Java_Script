let str = "you are looking to upgrade your skill set, you can sign up on our SkillUp platform, a Simplilearn initiative";
str1 = str.replace("looking","showing");
document.write("replace string is:-"+str1);