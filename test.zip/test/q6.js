let str="you are looking to upgrade your skill set, you can sign up on our SkillUp platform, a Simplilearn initiative";
document.write("UpperCase string is:-&nbsp"+str.toUpperCase()+"<br>");