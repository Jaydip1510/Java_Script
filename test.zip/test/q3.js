let str = "Hope this article helped you understand JavaScript Examples. In this article, we explored the concept of JavaScript code structure with the different ways of declaration";
str1 = str.replace(/JavaScript/g,"JS");
document.write("String Replace is:-"+str1);