let arr = [23,33,45,43,12];
let arr2 = arr.filter(function(t){
    return t%2===0;
});
document.write(arr2);


