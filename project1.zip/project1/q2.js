let a = 5;
let b = 7;

document.write("Before swapping a:-"+a+"<br>");
document.write("Before swapping b:-"+b+"<br>");
let c = a;
a = b;
b = c;
document.write("After swapping a:- "+a+"<br>"); 
document.write("After swapping b:- "+b+"<br>"); 