let celsius = 25;
let fahrenheit = (celsius * 9/5) + 32;

document.write(+(celsius)+"°C is equal to" +(fahrenheit)+"°F");
