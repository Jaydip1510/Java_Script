let ch = prompt("Enter choice Week:-");

switch(ch){
         case 'M':
              document.write("Monday");
              break;
         case 't':
              document.write("Tuesday");
              break;
         case 'W':
              document.write("Wednesday");
              break;
         case 'T':
              document.write("Thursday");
              break;
         case 'F':
              document.write("Friday");
              break;
         case 's':
              document.write("Saturday");
              break;
         case "S":
              document.write("Sunday");
              break;
    default:
             document.write("Invaild choice");
             break;
          
}