let no = prompt("Enter Any Number:-");
(no%2==0) ? document.write(no+"&nbspis even"):document.write(no+"&nbspno is odd");