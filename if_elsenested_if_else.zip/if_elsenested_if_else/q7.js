let a = prompt("Enter the first number:-");
let b = prompt("Enter the sencond number:-");
if(a === b){
     document.write("The number are the same");
}else if(a>b){
    document.write("the first number greater ");
        
}else{
    document.write("the first number less");
}