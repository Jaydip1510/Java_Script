let no = prompt("Enter Any Number:-");
if(no>0){
      document.write(no+"&nbspis positive");
}else if(no<0){
    document.write(no+"&nbspis Nagative");
}else{
    document.write(no+"&nbspis zero");
}