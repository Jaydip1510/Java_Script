let i = 1;
while(i<=10){
      document.write(i+"<br>");
      i++;
}