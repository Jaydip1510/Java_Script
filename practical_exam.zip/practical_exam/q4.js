let num = prompt("Enter Any Number:-");

if (num > 0) {
  document.write("The number is positive.");
} else if (num < 0) {
  document.write("The number is negative.");
} else {
  document.write("The number is zero.");
}
