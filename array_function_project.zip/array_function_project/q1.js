let arr = [];
let size = 8;
let i;
for(i=0;i<size;i++){
     arr[i] = prompt("Enter Element:-");
}
document.write("Array element is:-"+arr+"<br>");