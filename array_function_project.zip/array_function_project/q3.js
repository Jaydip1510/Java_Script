let arr = ["jaydip","dhoni","raj","jay","arjun"];

let arr2 = arr.toString();
document.write("String is:-"+arr2+"<br>");