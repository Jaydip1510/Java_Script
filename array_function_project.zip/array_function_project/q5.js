let a = [45,95,68,54,82,16,29,10,34,78];
document.write(a.sort(function(a,b){ return b-a}));
for(i=0;i<d.length;i++){
        document.write(d[i]+"<br>");
 }