let arr = [10,20,30,40,50,60];
arr.forEach(function(val,i){
    document.write("index is:"+i+":-"+val+"<br>");
});