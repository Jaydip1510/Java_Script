
window.addEventListener("DOMContentLoaded", (event) => {
    display();
    var cat_html = '';
    let category_data = localStorage.getItem("categoryData");
    if(category_data != null)
    {
        category_data = JSON.parse(category_data);
            category_data.forEach(element => {
                cat_html+="<option value='"+element.id+"'>"+element.name+"</option>"
            });
        
    }
    document.getElementById("category").innerHTML = cat_html;

});

document.getElementById("btn").addEventListener("click",()=>{
    let category_data = localStorage.getItem("categoryData");
    if(category_data != null)
    {
        category_data = JSON.parse(category_data);
    }
    let imag  = document.product.pimg.value;
    let pname = document.product.pname.value;
    let price = document.product.price.value;
    let catid = document.product.category.value;
    let proid = document.product.pid.value;
    let found = category_data.find(function (element) {
        return element.id == catid;
    });
    let catname = found.name;
    let pdetail = {
        "product_id" : 0,
        "catogory_id": catid,
        "catogory_name": catname,
        "product_img": imag,
        "product_name": pname,
        "product_price":price

    };
    let data = JSON.parse(localStorage.getItem("productDetail"));
    if(data != null){
        if(proid.length > 0){
             for(let i = 0; i < data.length; i++){
                if(proid == data[i].product_id){
                data[i].product_img     = imag;
                data[i].product_name    = pname;
                data[i].product_price   = price;
                data[i].catogory_id     = catid;
                data[i].catogory_name   = catname;
              }
            }
        }else{
            pdetail.product_id = 1;
            let len = data.length;
            if(len > 0)
            {
                pdetail.product_id =  len + 1;
            }
            data.push(pdetail);
        }
        localStorage.setItem("productDetail",JSON.stringify(data));
    }else{
        let pdata = [];
        pdata.push(pdetail);
        localStorage.setItem("productDetail",JSON.stringify(pdata));
    }
    document.product.reset();
    document.product.pid.value = '';
    
    display();
});

function display(){
      let pdt = "<tr>";
      pdt +="<th>Id</th>";
      pdt +="<th width='10%'>Image</th>";
      pdt +="<th>Product Name</th>";
      pdt +="<th>Price</th>";
      pdt +="<th>Catogery Id</th>";
      pdt +="<th>Catogory Name</th>";
      pdt +="<th>Action</th>";
      pdt +="</tr>";

      let prd = localStorage.getItem("productDetail");

      if(prd != null){
        let prddetail = JSON.parse(prd);
        for(let i = 0; i<prddetail.length;i++){
            pdt +="<tr>";
            pdt +="<td>"+prddetail[i].product_id+"</td>";
            pdt +="<td>"+prddetail[i].product_img+"</td>";
            pdt +="<td>"+prddetail[i].product_name+"</td>";
            pdt +="<td>"+prddetail[i].product_price+"</td>";
            pdt +="<td>"+prddetail[i].catogory_id+"</td>";
            pdt +="<td>"+prddetail[i].catogory_name+"</td>";
            pdt += "<td><center><input type='button' name='prddel' id='prddel' value='Delete' onclick='delete_product(" + prddetail[i].product_id + ")'>";
            pdt += "   <input type='button' name='prdedit' id='prdedit' value='Edit' onclick='edit_product(" + prddetail[i].product_id + ")'></td>";
            pdt +="</tr>";
        }
      }
      document.getElementById("ptable").innerHTML = pdt;
}
function edit_product(id)
{

  let prodata = localStorage.getItem("productDetail");
  let data = JSON.parse(prodata);  
    for (let i = 0; i < data.length; i++) {
           if(id == data[i].product_id){
            document.product.pid.value = id;
            document.product.pimg.value = data[i].product_img;
            document.product.pname.value = data[i].product_name;
            document.product.price.value = data[i].product_price;
            document.product.cat_id.value = data[i].catogory_id;

           }  
  } 
}
function delete_product(id){
    let data = JSON.parse(localStorage.getItem("productDetail"));
    for (let i = 0; i < data.length; i++) {
        if(id == data[i].product_id){
         data.splice(i,1);
        }
    }
    localStorage.setItem("productDetail",JSON.stringify(data));
    display();   
}